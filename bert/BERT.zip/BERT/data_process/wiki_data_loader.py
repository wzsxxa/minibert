import os
import random
import torch
from wiki_dataset import _WikiTextDataset
from d2l import torch as d2l

#返回的paragraphs是一个段落列表 ， 每一个段落又是一个句子列表。
def _read_wiki(data_dir):
    file_name = os.path.join(data_dir , 'wiki.train.tokens')
    with open(file_name  , 'r' , encoding='utf-8' ) as f:
        lines  = f.readlines()
    paragraphs = [line.strip().lower().split(' . ')
                  for line in lines if len(line.split(' . ')) >= 2]
    random.shuffle(paragraphs)
    return paragraphs



# batch_size 为小批量中的样本数
# max_len 为样本长度（即输入bert模型的序列长度） 虽然名字是max_len，但由于padding操作，每个
#其实样本的长度都是 max_len
def load_data_wiki(batch_size , max_len):
    # dataloader使用两个额外进行装载数据。当num_workers为 0 时 ，表示只使用主进程装载数据
    num_workers = 2
    #从网站上下载wikitext-2并解压到本地wikitext-2目录
    # data_dir = d2l.download_extract('wikitext-2' , 'wikitext-2')
    data_dir = '..\\data\\wikitext-2'
    paragraphs = _read_wiki(data_dir)
    # for paragraph in paragraphs:
    #     print(paragraph)
    train_set = _WikiTextDataset(paragraphs , max_len)
    print(len(paragraphs))
    train_iter = torch.utils.data.DataLoader(train_set , batch_size ,
                                             shuffle = True, num_workers = num_workers)
    print(batch_size)
    for (tokens_X, segments_X, valid_lens_x, pred_positions_X, mlm_weights_X,
         mlm_Y, nsp_y) in train_iter:
        print(tokens_X.shape, segments_X.shape, valid_lens_x.shape,
              pred_positions_X.shape, mlm_weights_X.shape, mlm_Y.shape,
              nsp_y.shape)
        # break

    return train_iter , train_set.vocab



if __name__ == '__main__':
    batch_size, max_len = 512, 64
    train_iter, vocab = load_data_wiki(batch_size, max_len)
    # cnt  = 0
    # for (tokens_X, segments_X, valid_lens_x, pred_positions_X, mlm_weights_X,
    #      mlm_Y, nsp_y) in train_iter:
    #     print(tokens_X.shape, segments_X.shape, valid_lens_x.shape,
    #           pred_positions_X.shape, mlm_weights_X.shape, mlm_Y.shape,
    #           nsp_y.shape)
    #     cnt += 1
    # print(cnt)
    #     # break
    # print(len(vocab))
    # path = load_data_wiki(0 , 0)
    # print(path)