import collections
import random
# from wiki_data_loader import _read_wiki
import torch.utils.data


#将一个句子列表（一维）中的每个句子拆分成一个单词列表 ， 因此最终返回的是一个二维列表
def tokenize(lines):
    return [line.split() for line in lines]



#将sentences转化为词典
def count_corpus(sentences):
    tokens = [token for sentence in sentences for token in sentence]
    return collections.Counter(tokens)


# Vocab类实现的功能：实现词元和索引的相互转化
class Vocab:
    def __init__(self , sentences , min_freq , reserved_tokens):
        counter  =count_corpus(sentences)
        self.token_freqs  =sorted(counter.items() , key= lambda  x : x[1] ,
                                  reverse= True)
        self.unk , uniq_tokens = 0 , ['<unk>'] + reserved_tokens
        uniq_tokens += [token for token , freq in self.token_freqs
                        if freq >= min_freq and token not in uniq_tokens]
        self.idx_to_token , self.token_to_idx = [] , dict()
        for token in uniq_tokens:
            self.idx_to_token.append(token)
            self.token_to_idx[token] = len(self.idx_to_token) - 1

#定义__len__后  , 再对Vocab实例使用len()函数时 会调用 __len__()
    def __len__(self):
        return len(self.idx_to_token)

#定义__getitem__后， 再对Vocab实例使用 [] 时 会调用 __getitem__()
    def __getitem__(self, tokens):
        return [self.token_to_idx.get(token , self.unk) for token in tokens]


#给定一个索引， 将其转化为token
    def to_token(self , idx):
        return self.idx_to_token[idx]


#注意这个函数返回的是一个元组列表， 元组中的tokens还是一个词元列表 ，并没有转化为索引
def _get_nsp_data_form_paragraph(paragraph, paragraphs , vocab , max_len):
    nsp_data_from_paragraph = []
    for i in range(len(paragraph) - 1):
        tokens_a , tokens_b , is_next  = _get_next_sentence(
            paragraph[i] , paragraph[i + 1] , paragraphs)
        #考虑1个'<cls>'词元和2个'<sep>'词元
        if len(tokens_a) + len(tokens_b) + 3 > max_len:
            continue
        tokens , segments = get_tokens_and_segments(tokens_a, tokens_b)
        nsp_data_from_paragraph.append((tokens , segments , is_next))
    return nsp_data_from_paragraph




def _get_next_sentence(tokens_a , tokens_b , paragraphs):
    is_next = True
    if random.random() < 0.5:
        is_next  = False
        tokens_b = random.choice(random.choice(paragraphs))
    return tokens_a , tokens_b , is_next


def get_tokens_and_segments(tokens_a , tokens_b):
    tokens = ['<cls>'] + tokens_a  + ['<sep>']
    segments = [0] * len(tokens)
    tokens += tokens_b + ['<sep>']
    segments += [1] * (len(tokens_b) + 1)
    return tokens , segments



#这个函数在_get_nsp_data_form_paragraph的基础上，把词元转化为索引
#同时也增加了一些训练语言模型需要的数据
#接受的输入可以理解为是 get_tokens_and_segments 返回的tokens
#函数的输出是 mlm_input_tokens 的索引 ，预测单词在tokens中的位置 ， 预测单词原值的索引
def _get_mlm_data_from_tokens(tokens , vocab):
    candidate_pred_positions =[]
    for i, token in enumerate(tokens):
        if tokens in ['<cls>' , '<sep>']:
            continue
        candidate_pred_positions.append(i)
        num_mlm_preds = max(1 , round(len(tokens) * 0.15))
        mlm_input_tokens, pred_positions_and_lables = _replace_mlm_tokens(tokens,
         candidate_pred_positions , num_mlm_preds , vocab)
        pred_positions_and_lables = sorted(pred_positions_and_lables ,
                                           key=lambda  x : x[0])
        pred_positions = [v[0] for v in pred_positions_and_lables]
        mlm_pred_lables = [v[1] for v in pred_positions_and_lables]
        # print(mlm_input_tokens)
        # print(mlm_pred_lables)
        return vocab[mlm_input_tokens] , pred_positions , vocab[mlm_pred_lables]



def _replace_mlm_tokens(tokens , candidate_pred_positions , num_mlm_preds, vocab):
    mlm_input_tokens = [token for token in tokens]
    pred_positions_and_lables = []
    #打乱后取前15%个位置作为被遮蔽的词元
    random.shuffle(candidate_pred_positions)
    for mlm_pred_position in candidate_pred_positions:
        if len(pred_positions_and_lables) >= num_mlm_preds:
            break
        masked_token = None

        if random.random() < 0.8:
            masked_token = '<mask>'
        else:
            # 10%的概率保持词元不变
            if random.random() < 0.5:
                masked_token = tokens[mlm_pred_position]
            else:
                idx = random.randint(0 , len(vocab) -1)
                masked_token = vocab.to_token(idx)
        mlm_input_tokens[mlm_pred_position] = masked_token
        pred_positions_and_lables.append((mlm_pred_position ,
                                          tokens[mlm_pred_position]))
        return mlm_input_tokens , pred_positions_and_lables



def _pad_bert_inputs(examples , max_len , vocab):
    max_num_mlm_preds = round(max_len * 0.15)
    all_token_ids , all_segments ,valid_lens = [] , [] ,[]
    all_pred_positions , all_mlm_weights , all_mlm_labels =[] ,[] ,[]
    nsp_labels = []
    for(token_ids , pred_positions , mlm_pred_label_ids ,  segments ,
        is_next ) in examples:
        all_token_ids.append(torch.tensor(token_ids + vocab[['<pad>']] *
                                        (max_len - len(token_ids)) , dtype=torch.long))
        all_segments.append(torch.tensor(segments + [0] * (max_len - len(segments)) ,
                                         dtype=torch.long))
        valid_lens.append(torch.tensor(len(token_ids) , dtype=torch.float32))
        all_pred_positions.append(torch.tensor(pred_positions + [0] * (max_num_mlm_preds - len(pred_positions)
                                                                       ), dtype=torch.long))
        all_mlm_weights.append(
            torch.tensor([1.0] * len(pred_positions) + [0.0] * (max_num_mlm_preds - len(pred_positions) ),
                         dtype=torch.float32))
        all_mlm_labels.append(torch.tensor(mlm_pred_label_ids + [0] *(max_num_mlm_preds - len(mlm_pred_label_ids)),
                                           dtype=torch.long))
        nsp_labels.append(torch.tensor(is_next , dtype=torch.long))
        return (all_token_ids , all_segments , valid_lens , all_pred_positions,
        all_mlm_weights , all_mlm_labels , nsp_labels)


class _WikiTextDataset(torch.utils.data.Dataset):
    def __init__(self , paragraphs , max_len):
 # 输⼊`paragraphs[i]`是代表段落的句⼦字符串列表；⽽输出`paragraphs[i]`是代表段落的句⼦列
        #表，其中每个句⼦都是词元列表
        paragraphs = [tokenize(paragraph) for paragraph in paragraphs]
        #sentences 是一个句子列表 ， 每一个句子又是一个词元列表
        sentences = [sentence for paragraph in paragraphs
                     for sentence in paragraph]
        self.vocab  = Vocab(sentences , min_freq=5 , reserved_tokens=
        ['<pad>' , '<mask>' , '<cls>' , '<sep>'])
        examples = []
        for paragraph in paragraphs:
            examples.extend(_get_nsp_data_form_paragraph(paragraph , paragraphs,
                                                         self.vocab , max_len))
        examples =[ (_get_mlm_data_from_tokens(tokens , self.vocab) + (segments , is_next))
            for tokens , segments , is_next in examples]
        print(f"examplesize: {len(examples)}")
        (self.all_token_ids , self.all_segments , self.valid_lens, self.all_pred_positions , self.all_mlm_weights,
         self.all_mlm_labels , self.nsp_labels) = _pad_bert_inputs(examples , max_len , self.vocab)

    def __getitem__(self, idx):
        return (self.all_token_ids[idx], self.all_segments[idx],
                self.valid_lens[idx], self.all_pred_positions[idx],
                self.all_mlm_weights[idx], self.all_mlm_labels[idx],
                self.nsp_labels[idx])

    def __len__(self ):
        return len(self.all_token_ids)







if __name__ == '__main__':
    # lines=["i am happy now" , "what a good day" , "sit on the floor"]
    # words = tokenize(lines)
    # print(words)
    data_dir = '..\\data\\wikitext-2'
    paragraphs = _read_wiki(data_dir)
    # for paragraph in paragraphs:
    #     print(paragraph)
    max_len = 64
    train_set = _WikiTextDataset(paragraphs, max_len)